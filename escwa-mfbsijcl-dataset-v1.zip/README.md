# ESCWA + MFBSIJCL Dataset

This dataset contains over 10,000 examples for fine-tuning LLaMA 3.2 3B with LoRA.
Each file includes JSONL-formatted entries with `instruction`, `input`, and `output` fields.
